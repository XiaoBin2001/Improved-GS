#include <glm/ext/scalar_packing.hpp>
#include <glm/ext/scalar_relational.hpp>

int test_packUnorm()
{
	int Error = 0;


	return Error;
}

int test_packSnorm()
{
	int Error = 0;


	return Error;
}

int main()
{
	int Error = 0;

	Error += test_packUnorm();
	Error += test_packSnorm();

	return Error;
}
